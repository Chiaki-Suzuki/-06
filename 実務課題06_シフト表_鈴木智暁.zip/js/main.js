let app = new Vue({
  el: '#app',
  data: {
    month: '',
    calendar: [],
    week: [],
    isSat: false,
    isSun: false
  },
  created: function() {
    // カレンダー作成
    let date = new Date();
    let year = date.getFullYear();
    let month = date.getMonth() + 1;
    this.month = month;
    let weekArray = ['日', '月', '火', '水', '木', '金', '土'];

    // 今月の終了日を取得
    let endDay = new Date(year, month, 0)

    // 空の配列に当月の日付をすべて格納したい
    let len = endDay.getDate();
    for (i = 1; i <= len; i++) {
      this.calendar.push(i)
    }

    // 曜日を充てる
    // 最初の週だけの曜日を繰り返す
    let startDay = new Date(year, month - 1, 1).getDay();
    for (i = 0; i < 1; i++){
      for (j = startDay; j < weekArray.length; j++) {
        this.week.push(weekArray[j]);
      }
    }

    // 最初と最後の週以外の曜日を繰り返す
    let firstWeek = (weekArray.length - startDay);
    let row = Math.floor((len - firstWeek) / weekArray.length);
    for (i = 0; i < row; i++) {
      for (j = 0; j < weekArray.length; j++) {
        this.week.push(weekArray[j])
      }
    }

    // 最後の週だけの曜日を繰り返す
    let lastWeek = endDay.getDay();
    for (i = 0; i <= lastWeek; i++) {
      this.week.push(weekArray[i])
    }

    // 15人分の日数分のカラムを表示
    let column = document.querySelectorAll('tr.person')
    for (i = 0; i < 15; i++) {
      for (j = 0; j < len; j++) {
        column[i].insertAdjacentHTML('beforeend', '<td></td>')
      }
    }
  },
  methods: {
    createShift: function () {
      // 一か月を四等分
      let date = new Date();
      let year = date.getFullYear();
      let month = date.getMonth() + 1;

      // 最初の週の日数
      let startDay = new Date(year, month - 1, 1).getDay();
      // 当月の日数
      let len = new Date(year, month, 0).getDay();

      let personColumn = document.querySelectorAll('tr.person td');

      let randoms = [];
      let min = 0;
      let max = 6;
      for (i = min; i <= max; i++) {
        while (true) {
          let tmp = this.randomFunc();
          if (!randoms.includes(tmp)) {
            randoms.push(tmp)
            break;
          }
        }
      }
      personColumn[randoms[0]].classList.add('red');
      personColumn[randoms[1]].classList.add('red');

      let randoms2 = [];
      let min2 = 0;
      let max2 = 6;
      for (i = min; i <= max; i++) {
        while (true) {
          let tmp = this.randomFunc2();
          if (!randoms2.includes(tmp)) {
            randoms2.push(tmp)
            break;
          }
        }
      }
      personColumn[randoms2[0]].classList.add('red');
      personColumn[randoms2[1]].classList.add('red');

      let randoms3 = [];
      let min3 = 0;
      let max3 = 6;
      for (i = min; i <= max; i++) {
        while (true) {
          let tmp = this.randomFunc3();
          if (!randoms3.includes(tmp)) {
            randoms3.push(tmp)
            break;
          }
        }
      }
      personColumn[randoms3[0]].classList.add('red');
      personColumn[randoms3[1]].classList.add('red');

      let randoms4 = [];
      let min4 = 0;
      let max4 = 6;
      for (i = min; i <= max; i++) {
        while (true) {
          let tmp = this.randomFunc4();
          if (!randoms4.includes(tmp)) {
            randoms4.push(tmp)
            break;
          }
        }
      }
      personColumn[randoms4[0]].classList.add('red');
      personColumn[randoms4[1]].classList.add('red');
    },
    randomFunc: function () {
      let ran = Math.floor(Math.random() * 7)
      return ran
    },
    randomFunc2: function () {
      let ran = Math.floor(Math.random() * 7) + 7
      return ran
    },
    randomFunc3: function () {
      let ran = Math.floor(Math.random() * 7) + 14
      return ran
    },
    randomFunc4: function () {
      let ran = Math.floor(Math.random() * 7) + 21
      return ran
    }
  }
})
